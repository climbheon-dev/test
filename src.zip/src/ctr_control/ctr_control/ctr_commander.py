import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
from interfaces.srv import RtsmIk 
import threading
import time

class CTRCommander(Node):
    def __init__(self):
        super().__init__('ctr_commander')

        # Hardware & Simulation을 위한 Publisher
        self.joint_pub = self.create_publisher(JointState, 'joint_states', 10)

        self.cli = self.create_client(RtsmIk, 'rtsm_ik')

        # 서비스 서버가 준비될 때까지 대기
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Solver service not available, waiting...')
        
        self.req = RtsmIk.Request()
        
        # 동기 처리를 돕기 위한 이벤트 객체 (입력 루프 제어용)
        self.response_event = threading.Event()

    def send_request(self, x, y, z):
        self.req.x = x
        self.req.y = y
        self.req.z = z
        
        # 이벤트를 초기화 (응답 대기 시작)
        self.response_event.clear()
        
        # 비동기 호출
        self.future = self.cli.call_async(self.req)
        self.future.add_done_callback(self.response_callback)
        
        return self.future

    def response_callback(self, future):
        try:
            response = future.result()
            
            # solvers가 계산해준 q값을 받음
            if response.success:
                self.get_logger().info(f"\n[Success] IK Solution: {response.q}")
                self.publish_joints(response.q)
            else:
                self.get_logger().warn("\n[Failed] IK Solver failed to find a solution.")
                
        except Exception as e:
            self.get_logger().error(f'\n[Error] Service call failed: {e}')
        
        finally:
            # 응답 처리 끝 알림
            self.response_event.set()

    def publish_joints(self, q_values):
        # q_values = [q1, q2, l1, l2] 
        msg = JointState()
        msg.header = Header()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = ['joint_tube1_rotate', 'joint_tube2_rotate', 'joint_tube1_slide', 'joint_tube2_slide']
        msg.position = q_values 
        
        self.joint_pub.publish(msg)
        self.get_logger().info("Published joint states to '/joint_states'")

def main(args=None):
    rclpy.init(args=args)
    node = CTRCommander()

    # ROS 2 노드를 백그라운드 스레드에서 실행 (Spin)
    # 이렇게 해야 input()이 메인 스레드를 잡고 있어도 콜백(결과 수신)이 동작함, 퀄리티 업!
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    try:
        print("\n=== CTR Commander Initialized ===")
        print("Enter Target Position (mm) to solve IK and move Robot.")
        
        while rclpy.ok():
            print("\n--- Enter Target Coordinate ---")
            try:
                # 사용자 입력
                x_input = input("x: ")
                y_input = input("y: ")
                z_input = input("z: ")
                
                # 입력값이 비어있으면 패스 (Enter만 쳤을 때 오류 방지, 자꾸 실수로 Enter 눌러서 추가해둠)
                if not x_input or not y_input or not z_input:
                    continue

                x = float(x_input)
                y = float(y_input)
                z = float(z_input)

                print(f"Sending Request -> x:{x}, y:{y}, z:{z} ...")
                node.send_request(x, y, z)
                
                # 응답이 올 때까지 메인 루프 대기
                node.response_event.wait()
                
            except ValueError:
                print("[!] Invalid input. Please enter numbers.")
            except Exception as e:
                print(f"[!] Error: {e}")

    except KeyboardInterrupt:
        print("\nShutting down commander...")
    
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()