"""
Solver들, 지금은 RTSM Solver만 존재
각 Solver 디렉토리에 서버, 클라이언트 따로 만들어줌
서버, 클라이언트 통합해서 어떤 Solver 사용할 지 고를 수 있다면 더 좋을듯?
나중에 다른 Solver 추가하면 xx_server, xx_client 형식으로 setup.py에 추가하기
어차피 여기 클라이언트는 안써서 필수는 아닌데 solver 개별 테스트 용으로 같이 만들어두면 좋긴 함
"""