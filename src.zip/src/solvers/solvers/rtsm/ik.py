import numpy as np


from solvers.rtsm.fk import forward_kinematics

def calculate_jacobian_fd(q, robot_params):
    """
    유한 차분법(Finite Difference)을 사용해 자코비안을 계산
    (Eq. 39, 401, 403)
    
    Args:
        q (np.array): 현재 조인트 변수 [th1, th2, l1, l2]
        robot_params (dict): 로봇 파라미터

    Returns:
        np.array: 3x4 자코비안 행렬 (J_k)
    """
    J = np.zeros((3, 4))
    
    # 논문에서 제안한 스텝 사이즈
    delta_theta = np.pi / 360.0  # rad
    delta_l = 0.25               # mm
    deltas = np.array([delta_theta, delta_theta, delta_l, delta_l])
    
    # P_B(q) 계산 (현재 위치)
    P_n = forward_kinematics(q, robot_params)
    
    for i in range(4):
        q_prime = q.copy()
        q_prime[i] += deltas[i]
        
        # P_B(q') 계산
        P_n_prime = forward_kinematics(q_prime, robot_params)
        
        # J_k의 i번째 열 계산
        # (P_B(q') - P_B(q)) / delta
        J[:, i] = (P_n_prime - P_n) / deltas[i]
        
    return J

def inverse_kinematics(P_target, q_initial, robot_params, max_iterations=100, set_error=1e-3, tau=1e-2):
    """
    Levenberg-Marquardt (LM) 알고리즘을 사용한 역방향 운동학
    
    Args:
        P_target (np.array): 목표 3D 위치 [x, y, z]
        q_initial (np.array): 초기 조인트 추정값 [th1, th2, l1, l2]
        robot_params (dict): 로봇 파라미터
        max_iterations (int): 최대 반복 횟수
        set_error (float): 허용 오차 (mm)
        tau (float): 댐핑 계수

    Returns:
        np.array: 계산된 조인트 변수 [th1, th2, l1, l2]
        None: 수렴 실패 시
    """
    
    q_k = q_initial.copy().astype(float)
    P_t = P_target.copy()
    
    # 가중치 행렬 W_E (논문에서는 간단히 1로 가정)
    W_E = np.eye(3)
    
    # 단위 행렬 I (4x4, 조인트 변수 개수 기준)
    I = np.eye(4)
    
    for i in range(max_iterations):
        # 현재 위치 P_n 및 오차 e_k 계산
        try:
            P_n = forward_kinematics(q_k, robot_params)
        except Exception as e:
            print(f"  [반복 {i+1}] FK 계산 실패: {e}. 이전 q 값 반환.")
            return q_k if i > 0 else None # 첫 시도부터 실패하면 None 반환
            
        e_k = P_t - P_n
        
        # 수렴 확인 (Is e_k < set_error?)
        error_norm = np.linalg.norm(e_k)
        if error_norm < set_error:
            print(f"  [반복 {i+1}] 수렴 성공! (오차: {error_norm:.6f} mm)")
            return q_k 
            
        # 자코비안 J_k 계산 
        J_k = calculate_jacobian_fd(q_k, robot_params)
        J_k_T = J_k.T
        
        # LM 알고리즘 계산 (Eq. 373-377)
        g_k = J_k_T @ W_E @ e_k
        
        # 댐핑 W_N 계산
        E_k = 0.5 * e_k.T @ W_E @ e_k
        W_N = tau * E_k * I
        
        H_k = J_k_T @ W_E @ J_k + W_N
        
        # q 업데이트
        try:
            # delta_q = H_k^(-1) * g_k
            delta_q = np.linalg.solve(H_k, g_k)
            q_k += delta_q
        except np.linalg.LinAlgError:
            print(f"  [반복 {i+1}] H_k가 특이 행렬(singular)입니다. 댐핑을 증가시킵니다.")
            # 댐핑을 크게 하여 경사 하강법처럼 동작하도록 함
            delta_q = (1.0 / (tau * E_k)) * g_k
            q_k += delta_q

        if (i+1) % 10 == 0:
             print(f"  [반복 {i+1}] 현재 오차: {error_norm:.6f} mm")

    # 최대 반복 횟수 초과
    print(f"IK 실패: 최대 반복 횟수({max_iterations}) 도달. 최종 오차: {error_norm:.6f} mm")
    return None