import numpy as np


from solvers.rtsm.utils import solve_bvp_combined 

# --- 3D 변환을 위한 헬퍼 함수 ---

def R_z(theta):
    """ Z축 회전 행렬 (4x4) """
    c, s = np.cos(theta), np.sin(theta)
    return np.array([
        [c, -s, 0, 0],
        [s,  c, 0, 0],
        [0,  0, 1, 0],
        [0,  0, 0, 1]
    ])

def R_y(theta):
    """ Y축 회전 행렬 (4x4) """
    c, s = np.cos(theta), np.sin(theta)
    return np.array([
        [ c, 0, s, 0],
        [ 0, 1, 0, 0],
        [-s, 0, c, 0],
        [ 0, 0, 0, 1]
    ])

def T_from_R_p(R, p):
    """ 회전 R과 위치 p로부터 4x4 변환 행렬 생성 """
    T = np.eye(4)
    T[0:3, 0:3] = R[0:3, 0:3]
    T[0:3, 3] = p
    return T

# --- 논문 수식 구현 ---

def calculate_friction_bc(q, params):
    """
    논문의 Eq. (14), (15), (16)에 따라 마찰 경계 조건을 계산
    B.C.2 = kappa_dot(L1) = (mu' / k_2z) * ||M_2|| * sgn(th_2m - th_1m)
    """
    theta_1m, theta_2m = q[0], q[1]
    
    mu_prime = params['mu_prime']
    K2z = params['K2z']
    K1_xy = params['K1_xy']
    K2_xy = params['K2_xy']
    K_sum_xy_inv = params['K_sum_xy_inv']
    u_hat_1_xy = params['u_hat_1_xy']
    u_hat_2_xy = params['u_hat_2_xy']

    # sgn 항 계산
    kappa_0 = theta_2m - theta_1m
    sgn_term = np.sign(kappa_0)
    
    # sgn(0) = 0 이므로, 마찰이 없는 경우 B.C.2 = 0
    if sgn_term == 0:
        return 0.0

    # ||M_2|| 계산 (Eq. 2, 7, 15 사용)
    
    # R_z 행렬 (2x2)
    Rz_th1 = R_z(theta_1m)[0:2, 0:2]
    Rz_th2 = R_z(theta_2m)[0:2, 0:2]
    
    # Eq. (15)로 u_F0 (월드 좌표계 곡률) 근사
    term1 = Rz_th1 @ K1_xy @ u_hat_1_xy
    term2 = Rz_th2 @ K2_xy @ u_hat_2_xy
    u_F0_xy = K_sum_xy_inv @ (term1 + term2)
    
    # Eq. (7)로 u_2 (튜브 2 좌표계 곡률) 계산
    Rz_T_th2 = Rz_th1.T # R_z(-theta_2m)
    u_2_xy = Rz_T_th2 @ u_F0_xy
    
    # Eq. (2)로 M_2 (튜브 2 모멘트) 계산
    M_2_xy = K2_xy @ (u_2_xy - u_hat_2_xy)
    M_2_norm = np.linalg.norm(M_2_xy)
    
    # B.C.2 (kappa_dot(L1)) 최종 계산 (Eq. 14/16)
    b_dynamic = (mu_prime / K2z) * M_2_norm * sgn_term
    
    return b_dynamic
    

def get_segment_transform(s, h, theta_1_s_func, theta_2_s_func, params):
    """
    Eq. (6), (7), (27), (28), (29)를 구현
    s 지점에서의 길이 h를 갖는 세그먼트의 바디 프레임 변환 행렬을 계산
    """

    K1_xy = params['K1_xy']
    K2_xy = params['K2_xy']
    K_sum_xy_inv = params['K_sum_xy_inv']
    u_hat_1_xy = params['u_hat_1_xy']
    u_hat_2_xy = params['u_hat_2_xy']

    # s 지점에서의 theta 값 계산
    th1 = theta_1_s_func(s)
    th2 = theta_2_s_func(s)
    
    Rz_th1 = R_z(th1)[0:2, 0:2] # 2x2 Z-Rotation
    Rz_th2 = R_z(th2)[0:2, 0:2] # 2x2 Z-Rotation
    
    # 곡률 계산 (Eq. 6, 7)
    u_F0_xy = K_sum_xy_inv @ (Rz_th1 @ K1_xy @ u_hat_1_xy + 
                             Rz_th2 @ K2_xy @ u_hat_2_xy)

    u_F2_xy = R_z(-th2)[0:2, 0:2] @ u_F0_xy
    
    u_x, u_y = u_F2_xy[0], u_F2_xy[1]
    kappa_norm = np.linalg.norm(u_F2_xy)

    # 세그먼트 기하 매개변수 계산 (Eq. 27, 28)
    alpha_k = h * kappa_norm # Eq. (27)
    phi_k = np.arctan2(-u_y, u_x) # Eq. (28)

    # 동차 변환 행렬 생성 (Eq. 29)
    if np.isclose(kappa_norm, 0): # 직선 세그먼트
        R_seg_main = np.eye(4)
        p_seg = np.array([0, 0, h])
    else:
        R_seg_main = R_y(alpha_k)
        p_seg = np.array([
            (1 - np.cos(alpha_k)) / kappa_norm,
            0,
            np.sin(alpha_k) / kappa_norm
        ])

    T_seg = R_z(phi_k) @ T_from_R_p(R_seg_main, p_seg) @ R_z(-phi_k)
    
    return T_seg


def forward_kinematics(q, robot_params):
    """
    순방향 운동학 (Section 4.1) 메인 함수
    
    Args:
        q (list/np.array): 로봇 입력 [theta_1m, theta_2m, l1, l2]
        robot_params (dict): 로봇의 모든 물리적 파라미터 딕셔너리
        
    Returns:
        np.array: 로봇 끝단의 3D 위치 [x, y, z]
    """
    # --- 입력 및 파라미터 준비 ---
    theta_1m, theta_2m, l1, l2 = q
    h = robot_params['h']
    
    # BVP Solver 입력
    kappa_0 = theta_2m - theta_1m      # B.C.1
    c_const = robot_params['c_const']  # Physical constant
    
    # B.C.2 (마찰 항) 동적 계산
    b_dynamic = calculate_friction_bc(q, robot_params)
    
    # $\theta(s)$ 분해에 필요한 파라미터
    K1z = robot_params['K1z']
    K2z = robot_params['K2z']
    K_sum_z = robot_params['K_sum_z']
    
    # Section 2에 필요한 파라미터
    u_hat_2_norm = robot_params['u_hat_2_norm']
    u_hat_2_xy = robot_params['u_hat_2_xy']

    # --- BVP 풀이 ---
    kappa_s_func = solve_bvp_combined(kappa_0, b_dynamic, l1, c_const)
    if kappa_s_func is None:
        raise RuntimeError(f"BVP 해법에 실패했습니다. (Inputs: k0={kappa_0:.4f}, b={b_dynamic:.6f}, L1={l1})")

    # --- $\theta(s)$ 함수 정의 (비틀림 모멘트 평형) ---
    def theta_1_s(s):
        kappa_s = kappa_s_func(s)
        return theta_1m - (K2z / K_sum_z) * (kappa_s - kappa_0)

    def theta_2_s(s):
        kappa_s = kappa_s_func(s)
        return theta_2m + (K1z / K_sum_z) * (kappa_s - kappa_0)

    # --- Section 1 (중첩 구간: 0 ~ l1) 계산 ---
    T_body_frame = np.eye(4)
    N = int(np.floor(l1 / h))
    h_end = l1 - N * h

    for k in range(N):
        s_mid = (k + 0.5) * h
        T_segment = get_segment_transform(s_mid, h, theta_1_s, theta_2_s, robot_params)
        T_body_frame = T_body_frame @ T_segment
        
    if h_end > 1e-6:
        s_mid_end = l1 - h_end / 2.0
        T_end_segment = get_segment_transform(s_mid_end, h_end, theta_1_s, theta_2_s, robot_params)
        T_body_frame = T_body_frame @ T_end_segment

    T_A_0 = R_z(theta_2m) @ T_body_frame

    # --- Section 2 (비중첩 구간: l1 ~ l2) 계산 ---
    l_section2 = l2 - l1
    
    if l_section2 > 1e-6:
        alpha_sec2 = l_section2 * u_hat_2_norm
        phi_sec2 = np.arctan2(-u_hat_2_xy[1], u_hat_2_xy[0])

        if np.isclose(u_hat_2_norm, 0):
            R_sec2 = np.eye(4)
            p_sec2 = np.array([0, 0, l_section2])
        else:
            R_sec2 = R_y(alpha_sec2)
            p_sec2 = np.array([
                (1 - np.cos(alpha_sec2)) / u_hat_2_norm,
                0,
                np.sin(alpha_sec2) / u_hat_2_norm
            ])
        
        T_B_A = R_z(phi_sec2) @ T_from_R_p(R_sec2, p_sec2) @ R_z(-phi_sec2)
        
    else:
        T_B_A = np.eye(4)

    # --- 최종 변환 및 위치 추출 ---
    T_B_0 = T_A_0 @ T_B_A
    P_B = T_B_0[0:3, 3]
    
    return P_B