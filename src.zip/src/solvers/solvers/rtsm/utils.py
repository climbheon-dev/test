import numpy as np
from typing import Callable, Optional, Union

def solve_bvp_taylor_4th(
    kappa_0: float, 
    kappa_dot_L1: float, 
    L1: float, 
    c: float
) -> Optional[Callable[[Union[float, np.ndarray]], Union[float, np.ndarray]]]:
    """
    4차 테일러 급수 전개를 이용한 BVP 해법
    
    논문의 Eq. (18) ~ (24)를 기반으로 함 
    (수정)
    이전과 다르게 계산 속도를 위해
    np.roots 대신 2차 방정식 근의 공식을 직접 사용, 써보고 문제 없으면 이대로 두면 될듯

    Args:
        kappa_0 (float): s=0에서의 비틀림 각도 (B.C.1, paper의 'a')
        kappa_dot_L1 (float): s=L1에서의 비틀림 변화율 (B.C.2, paper의 'b')
        L1 (float): 튜브의 길이
        c (float): 물리 상수 ((1+v) * ||u1|| * ||u2||)

    Returns:
        Callable: s를 입력받아 kappa(s)를 반환하는 함수 (해를 못 찾으면 None)
    """
    
    # 상수 미리 계산
    a = kappa_0
    b = kappa_dot_L1
    sin_a = np.sin(a)
    cos_a = np.cos(a)
    
    # 2차 방정식 계수 계산
    # x2 * (kappa_dot_0)^2 + x1 * (kappa_dot_0) + x0 = 0
    
    # k_2 = c * sin_a
    # k_4_term0 = -c * sin_a
    # k_4_term1 = c * cos_a * (c * sin_a)
    
    k_2 = c * sin_a
    k_4_term0 = -c * sin_a
    k_4_term1 = c * cos_a * k_2

    L1_2 = L1**2
    L1_3 = L1**3

    x2 = (k_4_term0 * L1_3) / 6.0
    x1 = 1.0 + (c * cos_a * L1_2) / 2.0
    x0 = (k_2 * L1) + (k_4_term1 * L1_3) / 6.0 - b

    # 2차 방정식 풀이 (근의 공식 적용으로 속도 최적화)
    kappa_dot_0 = 0.0
    
    if abs(x2) < 1e-12:  # 2차항이 0인 경우 (1차 방정식)
        if abs(x1) < 1e-12:
            return None # 해 없음
        kappa_dot_0 = -x0 / x1
    else:
        det = x1**2 - 4*x2*x0
        
        if det < 0:
            # 판별식이 음수면 실수 해가 없음
            # 필요 시 로깅 추가
            return None
            
        sqrt_det = np.sqrt(det)
        root1 = (-x1 + sqrt_det) / (2*x2)
        root2 = (-x1 - sqrt_det) / (2*x2)
        
        # 논문에 따라 0에 더 가까운 해를 물리적으로 타당한 해로 선택
        if abs(root1) < abs(root2):
            kappa_dot_0 = root1
        else:
            kappa_dot_0 = root2

    # 테일러 계수 확정
    x = kappa_dot_0
    
    k_0 = a
    k_1 = x
    # k_2는 위에서 계산됨
    k_3 = c * cos_a * x
    k_4 = k_4_term0 * (x**2) + k_4_term1

    # 클로저 함수 반환 (Eq. 18)
    def K_s(s: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        s_arr = np.asarray(s)
        s2 = s_arr**2
        return (k_0 + 
                k_1 * s_arr + 
                k_2 * (s2 / 2.0) + 
                k_3 * (s2 * s_arr / 6.0) + 
                k_4 * (s2 * s2 / 24.0))

    return K_s

def solve_bvp_taylor_6th(
    kappa_0: float, 
    kappa_dot_L1: float, 
    L1: float, 
    c: float
) -> Optional[Callable[[Union[float, np.ndarray]], Union[float, np.ndarray]]]:
    """
    6차 테일러 급수 전개를 이용한 BVP 해법

    4차 테일러 급수에서는 np.roots를 제거하여 속도를 올렸으나
    6차 테일러 급수에서는 4차 다항식을 풀어야 하므로 따로 수정 더 안하고 np.roots를 사용하는 방식 그대로 둠

    Args:
        kappa_0 (float): s=0에서의 비틀림 각도 (B.C.1, paper의 'a')
        kappa_dot_L1 (float): s=L1에서의 비틀림 변화율 (B.C.2, paper의 'b')
        L1 (float): 튜브의 길이
        c (float): 물리 상수 ((1+v) * ||u1|| * ||u2||)

    Returns:
        Callable: s를 입력받아 kappa(s)를 반환하는 함수 (해를 못 찾으면 None)
    """
    
    a = kappa_0
    b = kappa_dot_L1
    sin_a = np.sin(a)
    cos_a = np.cos(a)

    # 기본 상수
    k_2 = c * sin_a

    # 다항식 계수 계산을 위한 거듭제곱 미리 계산
    L1_2 = L1**2
    L1_3 = L1**3
    L1_4 = L1**4
    L1_5 = L1**5

    # kappa_dot(0)를 x라 할 때, B.C.2를 만족하는 4차 방정식 P(x) = 0 의 계수들
    
    p4 = (c * sin_a * L1_5) / 120.0
    
    p3 = (-c * cos_a * L1_4) / 24.0
    
    p2 = (-c * sin_a * L1_3 / 6.0) + \
         (-6*c*cos_a*k_2 - 5*c**2*sin_a*cos_a) * (L1_5 / 120.0)
         
    p1 = 1.0 + (c * cos_a * L1_2 / 2.0) + \
         (c**2*cos_a**2 - 3*c*sin_a*k_2) * (L1_4 / 24.0)
         
    p0 = (k_2 * L1) + (c * cos_a * k_2 * L1_3 / 6.0) + \
         (c**2*cos_a**2*k_2 - 3*c*sin_a*k_2**2) * (L1_5 / 120.0) - b

    # 4차 방정식 풀이
    roots = np.roots([p4, p3, p2, p1, p0])

    # 허수부가 매우 작은 복소수는 실수로 간주 (수치 오차 보정)
    real_roots = roots[np.abs(roots.imag) < 1e-6].real
    
    if len(real_roots) == 0:
        return None

    # 0에 가장 가까운 해 선택
    kappa_dot_0 = real_roots[np.argmin(np.abs(real_roots))]
    x = kappa_dot_0

    # 계수 재구성
    x2 = x**2
    k_0 = a
    k_1 = x
    # k_2는 위에서 계산됨
    k_3 = c * cos_a * x
    k_4 = -c * sin_a * x2 + c * cos_a * k_2
    k_5 = -c * cos_a * (x**3) - 3*c*sin_a*k_2 * x + c**2*cos_a**2 * x
    k_6 = c * sin_a * (x**4) - (6*c*cos_a*k_2 + 5*c**2*sin_a*cos_a) * x2 + \
          (c**2*cos_a**2*k_2 - 3*c*sin_a*k_2**2)

    def K_s(s: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        s_arr = np.asarray(s)
        s2 = s_arr**2
        return (k_0 + 
                k_1 * s_arr + 
                k_2 * (s2 / 2.0) + 
                k_3 * (s2 * s_arr / 6.0) + 
                k_4 * (s2 * s2 / 24.0) +
                k_5 * (s2 * s2 * s_arr / 120.0) +
                k_6 * (s2 * s2 * s2 / 720.0))

    return K_s

def solve_bvp_combined(
    kappa_0: float, 
    kappa_dot_L1: float, 
    L1: float, 
    c: float, 
    w: float = 0.45
) -> Optional[Callable[[Union[float, np.ndarray]], Union[float, np.ndarray]]]:
    """
    4차 및 6차 모델 결합
    
    논문에서 제안한 정확도 향상 기법으로, 서로 반대 방향의 오차를 가진
    두 모델을 가중 평균하여 오차를 상쇄
    
    Eq. (40): kappa(s) = w * kappa_4th(s) + (1-w) * kappa_6th(s)
    
    Args:
        w (float): 가중치 (논문 추천값: 0.45를 사용)
    """
    
    # 두 모델 각각 생성
    model_4th = solve_bvp_taylor_4th(kappa_0, kappa_dot_L1, L1, c)
    if model_4th is None:
        return None
        
    model_6th = solve_bvp_taylor_6th(kappa_0, kappa_dot_L1, L1, c)
    if model_6th is None:
        return None

    # 결합된 함수 반환
    def K_combined(s: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        return w * model_4th(s) + (1.0 - w) * model_6th(s)
        
    return K_combined