import numpy as np

# --- 1. 로봇 물리 파라미터 정의 (논문 기준에 튜브 단면만 내꺼로 수정) ---

# 튜브 제원 (Fig. 1)
R1 = 65.0  # Outer tube 굽힘 반경 (mm)
R2 = 55.0  # Inner tube 굽힘 반경 (mm)

# 재료 물성치
E = 3.16e10 # Pa
v = 0.3     # Poisson's ratio
G = E / (2 * (1 + v)) # Shear modulus

# 튜브 단면
OD1, ID1 = 1.3, 1.04
OD2, ID2 = 0.9, 0.56

# 관성 모멘트 (I) 및 극관성 모멘트 (Ip)
I1 = (np.pi / 64.0) * (OD1**4 - ID1**4)
I2 = (np.pi / 64.0) * (OD2**4 - ID2**4)
Ip1 = (np.pi / 32.0) * (OD1**4 - ID1**4)
Ip2 = (np.pi / 32.0) * (OD2**4 - ID2**4)

# 강성 (Eq. 3)
K1_xy_val = E * I1
K2_xy_val = E * I2
K1z = G * Ip1
K2z = G * Ip2
K_sum_z = K1z + K2z

# (x,y) 굽힘 강성 행렬 (2x2)
K1_xy = np.array([[K1_xy_val, 0], [0, K1_xy_val]])
K2_xy = np.array([[K2_xy_val, 0], [0, K2_xy_val]])
K_sum_xy_inv = np.linalg.inv(K1_xy + K2_xy)

# 초기 곡률 벡터 (x-z 평면 굽힘 가정)
u_hat_1_xy = np.array([1.0 / R1, 0])
u_hat_2_xy = np.array([1.0 / R2, 0])
u_hat_2_norm = np.linalg.norm(u_hat_2_xy)

# --- 2. BVP Solver용 상수 정의 ---

# BVP 상수 'c'
c_const = (1.0 + v) * np.linalg.norm(u_hat_1_xy) * u_hat_2_norm

# 마찰 계수 (논문 섹션 6.2에서 실험적으로 결정된 값, 나중엔 실험을 통해 내 하드웨어에 맞게 수정 필요함.)
mu_prime = -0.8

# --- 3. FK 알고리즘 파라미터 ---
h = 0.25 # 세그먼트 길이 (mm)

# --- 4. 모든 파라미터를 딕셔너리로 통합 ---
robot_params = {
    'h': h,
    'K1_xy': K1_xy,
    'K2_xy': K2_xy,
    'K_sum_xy_inv': K_sum_xy_inv,
    'K1z': K1z,
    'K2z': K2z,
    'K_sum_z': K_sum_z,
    'u_hat_1_xy': u_hat_1_xy,
    'u_hat_2_xy': u_hat_2_xy,
    'u_hat_2_norm': u_hat_2_norm,
    'c_const': c_const,
    'mu_prime': mu_prime
}