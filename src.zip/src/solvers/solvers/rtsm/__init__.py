"""
Concentric tube robot: a real-time static model considering friction이라는 논문 기반 IK Solver
"""