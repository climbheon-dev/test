import numpy as np
import rclpy
from rclpy.node import Node

# 인터페이스
from interfaces.srv import RtsmIk

# 로봇 물리 파라미터 설정
from solvers.rtsm.config import robot_params

# 계산
from solvers.rtsm.fk import forward_kinematics
from solvers.rtsm.ik import inverse_kinematics

class RTSM:
    """
    Real-Time Static Model
    """
    def __init__(self, params):
        """
        Args:
            params (dict): 로봇의 물리적 파라미터
        """
        self.params = params
        # 출력 소수점 설정
        np.set_printoptions(precision=4, suppress=True)

    def solve_ik(self, target_pose, q_init, max_iter=100, tol=1e-3):
        """
        Solve inverse kinematics
        오차가 너무 적은거 아니냐는 질문이 들어왔는데.. 솔직히 그렇긴 한데 오차를 늘리고 싶지가 않음.
        오차 적으면 좋잖아 한잔해
        """
        q_solution = inverse_kinematics(
            target_pose,
            q_init,
            self.params,
            max_iterations=max_iter,
            set_error=tol
        )
        return q_solution
    
    def solve_fk(self, q_solution):
        """
        Inverse kinematics를 통해 구한 q_solution을 이용해 Forward kinematics를 계산
        """
        reached_pose = forward_kinematics(q_solution, self.params)

        return reached_pose

class Server(Node):

    def __init__(self):
        super().__init__('server')
        self.srv = self.create_service(RtsmIk, 'rtsm_ik', self.callback)

    def callback(self, req, res):

        target_x = req.x
        target_y = req.y
        target_z = req.z

        target_pose = np.array([target_x, target_y, target_z])

        # 초기 추정값
        q_init = np.array([0.0, np.pi/2.0, 40.0, 50.0])
        CTR = RTSM(robot_params)

        # Solve IK
        q_solution = CTR.solve_ik(target_pose, q_init)

        if q_solution is not None:
            res.success = True
            res.q = q_solution.tolist()
        else:
            res.success = False
            res.q = [] 
            
        self.get_logger().info('Incoming request\nx: %.2f y: %.2f z: %.2f' % (req.x, req.y, req.z))

        return res
    
def main(args=None):
    rclpy.init(args=args)
    server = Server()
    rclpy.spin(server)
    rclpy.shutdown()

if __name__ == '__main__':
    main()