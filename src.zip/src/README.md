# ROS2 프로젝트

## 실행 방법

```bash
ros2 run solvers rtsm_server
```
```bash
ros2 run hardware_controller bridge_node
```
```bash
ros2 run ctr_control commander_node
```

* commander_node에 x, y, z 값을 입력하여 실행.