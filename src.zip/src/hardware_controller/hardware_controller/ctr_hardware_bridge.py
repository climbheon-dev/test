"""
TODO: 현재 52줄~while 문까지 응답 대기하는 부분이 있는데 이 부분에서 딜레이가 생길 수 있어보임.
      나중에 응답 확인을 별도의 스레드에서 처리하도록 수정하는 것 고려해보기. 지금은 시간 부족으로 일단 유지.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import serial
import time

class CtrHardwareBridge(Node):
    def __init__(self):
        super().__init__('ctr_hardware_bridge')
        
        try:
            # 타임아웃 0.1초
            self.ser = serial.Serial('/dev/ttyACM0', 115200, timeout=0.1)
            self.get_logger().info('Connected to Hardware on /dev/ttyACM0')
        except serial.SerialException as e:
            self.get_logger().error(f'Failed to connect to serial: {e}')
            exit(1)

        self.subscription = self.create_subscription(
            JointState,
            '/joint_states',
            self.listener_callback,
            10
        )
        self.last_sent_msg = ""

    def listener_callback(self, msg):
        if len(msg.position) < 4:
            return

        rot1 = msg.position[0]
        rot2 = msg.position[1]
        len1 = msg.position[2]
        len2 = msg.position[3]

        # 아두이노로 보낼 명령어
        command_str = f"{rot1:.4f},{rot2:.4f},{len1:.4f},{len2:.4f}\n"

        if command_str != self.last_sent_msg:
            try:
                self.ser.reset_input_buffer()
                self.ser.write(command_str.encode('utf-8'))
                self.last_sent_msg = command_str
                self.get_logger().info(f"Sending: {command_str.strip()}")

                # 아두이노가 잘 받았는지 응답 대기, 근데 괜히 느려질 수 있어서 나중에 확인 후 수정 필요
                time.sleep(0.02) 
                
                while self.ser.in_waiting > 0:
                    response = self.ser.readline().decode('utf-8', errors='ignore').strip()
                    if response.startswith("ACK"):
                        self.get_logger().info(f"[Arduino] {response}")
                    else:
                        self.get_logger().info(f"[Arduino Log] {response}")

            except serial.SerialException as e:
                self.get_logger().error(f"Serial Error: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = CtrHardwareBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.ser.is_open:
            node.ser.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()